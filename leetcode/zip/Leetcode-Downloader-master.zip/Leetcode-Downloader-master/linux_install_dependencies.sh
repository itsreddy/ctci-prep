#!/bin/sh
sudo pip3 install requests
sudo pip3 install selenium
sudo pip3 install bs4
